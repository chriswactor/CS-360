package com.example.inventoryapp_chriswactor;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "app.db";
    public static final int DB_VERSION = 2;

    public DBHelper(Context ctx) {
        super(ctx, DB_NAME,null, DB_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE IF NOT EXISTS users (" +
                        "  id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "  username TEXT UNIQUE NOT NULL," +
                        "  password TEXT NOT NULL" +
                        ")"
        );
        db.execSQL(
                "CREATE TABLE IF NOT EXISTS items (" +
                        "  id   INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "  name TEXT NOT NULL UNIQUE," +
                        "  qty  INTEGER NOT NULL DEFAULT 0" +
                        ")"
        );
        // create a unique index
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_items_name ON items(name)");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        if (oldV < 2) {
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_items_name ON items(name)");
        }
    }
}


