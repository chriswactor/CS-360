package com.example.inventoryapp_chriswactor;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MainActivity extends AppCompatActivity implements ItemAdapter.Callbacks {

    private ItemRepository items;
    private ItemAdapter adapter;
    private TextView smsBanner;
    private SharedPreferences prefs;
    private static final String PREFS = "prefs";
    private static final String KEY_SMS_OK = "sms_ok";
    private static final int LOW_THRESHOLD = 5;

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                prefs.edit().putBoolean(KEY_SMS_OK, granted).apply();
                refreshSmsBanner();
            });

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        items = new ItemRepository(this);
        RecyclerView rv = findViewById(R.id.recycler);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ItemAdapter(items.all(), this);
        rv.setAdapter(adapter);

        EditText inputName = findViewById(R.id.inputName);
        EditText inputQty  = findViewById(R.id.inputQty);
        Button buttonAdd   = findViewById(R.id.buttonAdd);
        smsBanner = findViewById(R.id.smsBanner);

        buttonAdd.setOnClickListener(v -> {
            String name = inputName.getText().toString();
            String qStr = inputQty.getText().toString();
            if(name.isEmpty() || qStr.isEmpty()){ Toast.makeText(this,"Enter name and qty",Toast.LENGTH_SHORT).show(); return; }
            int qty = Integer.parseInt(qStr);
            items.add(name, qty);
            reload();
            inputName.setText(""); inputQty.setText("");
            maybeSendLowStock(name, qty);
        });

        smsBanner.setOnClickListener(v -> requestSmsIfNeeded());
        refreshSmsBanner();
    }

    private void reload(){ adapter.setData(items.all()); }

    private void refreshSmsBanner(){
        boolean ok = prefs.getBoolean(KEY_SMS_OK, false);
        smsBanner.setText(ok ? "SMS alerts enabled" : "Enable SMS alerts for low inventory");
        smsBanner.setBackgroundColor(ok ? 0xFF388E3C : 0xFF3F51B5);
    }

    private void requestSmsIfNeeded(){
        boolean ok = prefs.getBoolean(KEY_SMS_OK, false);
        if(ok) return;
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED){
            prefs.edit().putBoolean(KEY_SMS_OK, true).apply();
            refreshSmsBanner();
        } else {
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void maybeSendLowStock(String name, int qty){
        boolean ok = prefs.getBoolean(KEY_SMS_OK, false);
        if(!ok) return;
        if(qty < LOW_THRESHOLD){
            try{
                SmsManager.getDefault().sendTextMessage("5551234567", null,
                        "Low stock: " + name + " (" + qty + " left)", null, null);
                Toast.makeText(this,"SMS sent",Toast.LENGTH_SHORT).show();
            }catch(Exception e){ Toast.makeText(this,"SMS failed",Toast.LENGTH_SHORT).show(); }
        }
    }
    @Override public void onPlus(ItemRepository.ItemRow r){
        items.updateQty(r.id, r.qty+1); reload();
    }
    @Override public void onMinus(ItemRepository.ItemRow r){
        int newQ = Math.max(0, r.qty-1);
        items.updateQty(r.id, newQ); reload();
        if(newQ < LOW_THRESHOLD) maybeSendLowStock(r.name, newQ);
    }
    @Override public void onDelete(ItemRepository.ItemRow r){
        items.delete(r.id); reload();
    }
}
