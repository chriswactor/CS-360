package com.example.inventoryapp_chriswactor;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteConstraintException;

public class UserRepository {
    private final DBHelper dbh;
    public UserRepository(Context ctx) {
        dbh = new DBHelper(ctx); }

    public boolean createUser(String u, String p) {
        SQLiteDatabase db = dbh.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", u.trim());
        cv.put("password", p);
        return db.insert("users", null, cv) != -1;
    }

    public boolean authenticate(String u, String p) {
        SQLiteDatabase db = dbh.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id FROM users WHERE username=? AND password=?",
                new String[]{u.trim(), p});
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }
}
