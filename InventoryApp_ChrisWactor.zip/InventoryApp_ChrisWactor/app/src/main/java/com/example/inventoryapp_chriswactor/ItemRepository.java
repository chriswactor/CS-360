package com.example.inventoryapp_chriswactor;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.*;

public class ItemRepository {
    private final DBHelper dbh;
    public static class ItemRow { public long id; public String name; public int qty;
        public ItemRow(long id, String name, int qty){ this.id=id; this.name=name; this.qty=qty; } }

    public ItemRepository(Context ctx){ dbh = new DBHelper(ctx); }

    public long add(String name, int qty) {
        String n = name.trim();
        SQLiteDatabase db = dbh.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put("name", n);
        cv.put("qty", qty);

        long id = db.insertWithOnConflict("items", null, cv, SQLiteDatabase.CONFLICT_IGNORE);

        if (id == -1) {
            // Row exists -> increment qty
            db.execSQL("UPDATE items SET qty = qty + ? WHERE name = ?", new Object[]{qty, n});

            // Return the existing row id
            Cursor c = db.rawQuery("SELECT id FROM items WHERE name=?", new String[]{n});
            try {
                if (c.moveToFirst()) id = c.getLong(0);
            } finally {
                c.close();
            }
        }
        return id;
    }
    public boolean updateQty(long id, int qty){
        SQLiteDatabase db = dbh.getWritableDatabase();
        ContentValues cv = new ContentValues(); cv.put("qty", qty);
        return db.update("items", cv, "id=?", new String[]{String.valueOf(id)})>0;
    }
    public boolean delete(long id){
        SQLiteDatabase db = dbh.getWritableDatabase();
        return db.delete("items","id=?", new String[]{String.valueOf(id)})>0;
    }
    public List<ItemRow> all(){
        List<ItemRow> out=new ArrayList<>();
        SQLiteDatabase db = dbh.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id,name,qty FROM items ORDER BY name", null);
        while(c.moveToNext()){ out.add(new ItemRow(c.getLong(0), c.getString(1), c.getInt(2))); }
        c.close(); return out;
    }
}

