package com.example.inventoryapp_chriswactor;

import android.view.*; import android.widget.*;
import androidx.annotation.NonNull; import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.VH> {
    public interface Callbacks {
        void onPlus(ItemRepository.ItemRow row);
        void onMinus(ItemRepository.ItemRow row);
        void onDelete(ItemRepository.ItemRow row);
    }
    private List<ItemRepository.ItemRow> data;
    private final Callbacks cb;
    public ItemAdapter(List<ItemRepository.ItemRow> data, Callbacks cb){ this.data=data; this.cb=cb; }
    public void setData(List<ItemRepository.ItemRow> d){ this.data=d; notifyDataSetChanged(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView name, qty; Button plus, minus, del;
        VH(View v){ super(v);
            name=v.findViewById(R.id.rowName); qty=v.findViewById(R.id.rowQty);
            plus=v.findViewById(R.id.btnPlus); minus=v.findViewById(R.id.btnMinus); del=v.findViewById(R.id.btnDelete);
        }
    }
    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int vt){
        return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.row_item, p, false));
    }
    @Override public void onBindViewHolder(@NonNull VH h, int i){
        ItemRepository.ItemRow r = data.get(i);
        h.name.setText(r.name); h.qty.setText(String.valueOf(r.qty));
        h.plus.setOnClickListener(v->cb.onPlus(r));
        h.minus.setOnClickListener(v->cb.onMinus(r));
        h.del.setOnClickListener(v->cb.onDelete(r));
    }
    @Override public int getItemCount(){ return data.size(); }
}
