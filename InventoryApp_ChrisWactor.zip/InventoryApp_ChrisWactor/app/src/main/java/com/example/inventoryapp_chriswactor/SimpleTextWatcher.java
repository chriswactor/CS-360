import android.text.Editable;
import android.text.TextWatcher;

class SimpleTextWatcher implements TextWatcher {
    private Runnable onChange;

    SimpleTextWatcher(Runnable onChange) {
        this.onChange = onChange;
    }

    @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
    @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
        onChange.run();
    }
    @Override public void afterTextChanged(Editable s) {}
}
