package com.example.inventoryapp_chriswactor;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private EditText userText, passText;
    private Button buttonLogin, buttonCreate;
    private UserRepository users;

    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_login);
        userText=findViewById(R.id.userText);
        passText=findViewById(R.id.passText);
        Button btnLogin=findViewById(R.id.buttonLogin);
        Button btnCreate=findViewById(R.id.buttonCreate);
        users = new UserRepository(this);

        btnLogin.setOnClickListener(v -> {
            try {
                String u = userText.getText().toString().trim();
                String p = passText.getText().toString().trim();
                if (u.isEmpty() || p.isEmpty()) {
                    Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
                    return;
                }

                UserRepository users = new UserRepository(this);
                if (users.authenticate(u, p)) {
                    Intent i = new Intent(LoginActivity.this, MainActivity.class);

                    startActivity(i);
                } else {
                    Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Log.e("Login", "Login failed", e);
                Toast.makeText(this, "Login error: " + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
            }
        });

        btnCreate.setOnClickListener(v -> {
            try {
                String u = userText.getText().toString().trim();
                String p = passText.getText().toString().trim();
                if (u.isEmpty() || p.isEmpty()) {
                    Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean ok = users.createUser(u, p);
                if (ok) {
                    Toast.makeText(this, "Account created. You can log in now.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Username already exists.", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Log.e("Login", "Create failed", e);
                Toast.makeText(this, "Create error: " + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
            }
        });


    }
}

